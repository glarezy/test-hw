<?php
return array(
	'login' => 'Login',
	'logout' => 'Logout',
	'star' => 'Поля со звездочкой {star} являются обязательными.',
	'authcode' => 'Проверочный код',
	'username' => 'Username',
	'password' => 'Password',
	'remember' => 'Remember me next time',
	'authcodetip' => 'Please enter the letters as they are shown in the image above.{n}Letters are not case-sensitive.',
	'loginfailed' => 'Incorrect username or password.',
);