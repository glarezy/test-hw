<?php
return array(
	'title' => 'Как купить',
	'desp' => 'Содержание',
	'finish' => 'We have received your infomation, we will contact you by email or phone.',
);