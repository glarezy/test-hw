<?php
return array(
	'contact' => 'Контакты',
);