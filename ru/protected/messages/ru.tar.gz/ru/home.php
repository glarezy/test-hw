<?php
return array(
	'home' => 'Главная',
	'h' => 'Home',
	'title' => 'YOUJIE',
	'news'=>'YOUJIE News',
);