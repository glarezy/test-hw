<?php
return array(
	'about' => 'О компании',
	'title' => 'Title',
	'content' => 'Content',
	'seo' => 'SEO',
);