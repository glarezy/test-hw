<?php
return array(
	'title' => 'Partner Register',
	'btnList' => 'List Application',
	'btnDel' => 'Delete Application',
	'manage' => 'Manage Application',
	'view' => 'View Application',
	'Region' => 'Region',
	'Tel' => 'Телефон',
	'Mob' => 'Mob',
	'Name' => 'Имя',
	'Company Name' => 'Наименование компании',
	'lastyear' => 'Question',
	'Current Products' => 'Current Products',
	'Industry involved' => 'Industry involved',
	'finish' => 'We have received an application for your cooperation, we will contact you by email or phone.',
);